<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Component\Outerscripts\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\Component\Portfoliocases\Site\Helper\RouteHelper as OuterscriptsHelperRoute;

class DisplayController extends BaseController
{
	public function display($cachable = false, $urlparams = array())
	{
		return parent::display();
	}
}
