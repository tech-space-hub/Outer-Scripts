<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Component\Outerscripts\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Categories\CategoryNode;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Factory;

abstract class RouteHelper
{
	public static function getOuterscriptRoute($id, $slug, $language = 0, $layout = null)
	{
		$link = 'index.php?option=com_outerscripts&view=outerscript&id=' . $id . '&slug=' . $slug;

		if ($language && $language !== '*' && Multilanguage::isEnabled()) {
			$link .= '&lang=' . $language;
		}

		if ($layout) {
			$link .= '&layout=' . $layout;
		}

		return $link;
	}
}
