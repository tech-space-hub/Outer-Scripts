<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Component\Outerscripts\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\ListModel;

class OuterscriptsModel extends ListModel
{
	public function __construct($config = array())
	{
		if (empty($config['filter_fields'])) {
			$config['filter_fields'] = array(
				'id', 'a.id',
				'title', 'a.title',
			);
		}

		parent::__construct($config);
	}

	protected function populateState($ordering = 'ordering', $direction = 'ASC')
	{
		$app = Factory::getApplication();
		$paramsCom = $app->getParams();
		$list_limit = $paramsCom->get('list_limit');

		$this->setState('list.limit', $list_limit);

		$value = $app->input->get('limitstart', 0, 'uint');
		$this->setState('list.start', $value);

		$orderCol = $app->input->get('filter_order', 'a.id');

		if (!in_array($orderCol, $this->filter_fields)) {
			$orderCol = 'a.id';
		}

		$this->setState('list.ordering', $orderCol);

		$listOrder = $app->input->get('filter_order_Dir', 'DESC');

		if (!in_array(strtoupper($listOrder), array('ASC', 'DESC', ''))) {
			$listOrder = 'DESC';
		}

		$this->setState('list.direction', $listOrder);

		$params = $app->getParams();
		$this->setState('params', $params);
	}

	protected function getStoreId($id = '')
	{
		return parent::getStoreId($id);
	}

	protected function getListQuery()
	{
		$db    = $this->getDbo();
		$query = $db->getQuery(true);
		$params      = $this->getState('params');
		$outerscript_location = $params->get('outerscript_location', 0);

		$query
			->select(array('a.id,a.type,a.title,a.inline_code,a.external_path,a.state'))
			->from($db->quoteName('#__outerscripts', 'a'))
			->where($db->quoteName('a.state') . ' = 1 ')
			->where($db->quoteName('a.id') . ' = ' . $outerscript_location . ' ')
			->order('a.id DESC');

		$query->order($this->getState('list.ordering', 'a.id') . ' ' . $this->getState('list.direction', 'DESC'));

		return $query;
	}

	public function getItems()
	{
		$items  = parent::getItems();
		return $items;
	}

	public function getStart()
	{
		return $this->getState('list.start');
	}
}
