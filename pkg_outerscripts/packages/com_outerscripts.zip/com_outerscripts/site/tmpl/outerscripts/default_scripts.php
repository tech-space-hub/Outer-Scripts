<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Outerscripts\Site\Helper\RouteHelper as OuterscriptsHelperRoute;

?>
<section class="outerScriptsSectionWrapper">
	<div class="outerscripts-container">
		<?php
		foreach ($this->items as $i => $item) :

			$inlineCode = $item->inline_code;
			$externalPath = $item->external_path;

			eval('?>' . $inlineCode);

			if (!empty($externalPath)) {
				$filepath = JPATH_SITE . '/' . $externalPath;
				if (is_file($externalPath)) {
					require_once($externalPath);
				} elseif (is_file($filepath))
					require_once $filepath;
				else{
					$html = '<div style="color: #ffffff;background: #6b3143;padding: 5px 15px;margin: 10px 0px;">'.Text::_('COM_OUTERSCRIPTS_INVALID_FILE_PATH').'</div>';
					echo sprintf($html, $filepath);
				}
			}

		endforeach;
		?>
	</div>
</section>
<?php
$document = JFactory::getDocument();
$componentPath = JURI::base() . 'components/com_outerscripts/assets/';
$document->addStyleSheet($componentPath . 'css/custom.style.css');
$document->addScript($componentPath . 'js/custom.script.js');
?>