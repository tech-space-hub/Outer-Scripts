<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

HTMLHelper::_('behavior.core');

$app	= JFactory::getApplication();
$paramsCom = $app->getParams();

?>

<?php if ($this->params->get('show_page_title')) { ?>
	<h1 class="mainHeading"><?php echo $this->escape($this->params->get('page_title')); ?></h1>
<?php } ?>

<div class="com-contact-categories categories-list">
	<?php
	echo $this->loadTemplate('scripts');
	?>
</div>