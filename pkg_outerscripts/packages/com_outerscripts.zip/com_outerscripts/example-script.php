<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/
 
defined('_JEXEC') or die('This file cannot be accessed directly.');

/************* Below are some sample codes that you can adapt to your needs. ************/

/* Setting Meta Data */

//$document = JFactory::getDocument();
//$document->setTitle('Title of Page');
//$document->setDescription('this is the description');
//$document->setGenerator('My Custom Code');
//$document->setMetaData('title', "Your meta title");
//$document->setMetaData('keywords', "keyword1,keyword2, etc.");
//$document->setMetaData('robots', "index,follow");
//$document->setMetaData('author', "Jobin Jose");

/* Regular Joomla Classes Usages */

//use Joomla\CMS\Factory;
//$user = Factory::getUser();
//echo $user->name;

/* Basic Session Access*/

//$session = JFactory::getSession();
//echo $session->getId();

/* Basic Get Method */

//$getparam = JFactory::getApplication()->input->get('urlparam', '', 'string');
//echo $getparam;

/* Basic Post Method */

//$getemail = JFactory::getApplication()->input->get('email', '', 'string');
//echo $getemail;

?>