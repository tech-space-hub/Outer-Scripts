--
-- Table structure for table `#__outerscripts`
--

CREATE TABLE IF NOT EXISTS `#__outerscripts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT 1 COMMENT '1=PHP,2=JS,3=CSS,4=HTML',
  `title` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inline_code` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_path` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE utf8mb4_unicode_ci;