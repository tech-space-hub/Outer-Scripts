<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Component\Outerscripts\Administrator\View\Outerscript;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\Toolbar;
use Joomla\CMS\Toolbar\ToolbarHelper;

class HtmlView extends BaseHtmlView
{
	protected $form;
	protected $item;
	protected $state;
	protected $canDo;

	public function display($tpl = null)
	{
		$this->form  = $this->get('Form');
		$this->item  = $this->get('Item');
		$this->state = $this->get('State');

		if (count($errors = $this->get('Errors'))) {
			throw new GenericDataException(implode("\n", $errors), 500);
		}

		$this->addToolbar();

		return parent::display($tpl);
	}

	protected function addToolbar()
	{
		Factory::getApplication()->input->set('hidemainmenu', true);
		$isNew      = ($this->item->id == 0);

		$canDo = ContentHelper::getActions('com_outerscripts');

		$toolbar = Toolbar::getInstance();

		ToolbarHelper::title(
			Text::_('COM_OUTERSCRIPTS_OUTERSCRIPT_PAGE_TITLE_' . ($isNew ? 'ADD_OUTERSCRIPT' : 'EDIT_OUTERSCRIPT'))
		);

		$toolbarButtons = [];

		if ($canDo->get('core.create')) {
			ToolbarHelper::apply('outerscript.apply');
			$toolbarButtons[] = ['save', 'outerscript.save'];
		}

		if ($canDo->get('core.create')) {
			$toolbarButtons[] = ['save2new', 'outerscript.save2new'];
		}

		if (!$isNew && $canDo->get('core.create')) {
			$toolbarButtons[] = ['save2copy', 'outerscript.save2copy'];
		}

		ToolbarHelper::saveGroup(
			$toolbarButtons,
			'btn-success'
		);

		$toolbar->cancel('outerscript.cancel', 'JTOOLBAR_CLOSE');
	}
}
