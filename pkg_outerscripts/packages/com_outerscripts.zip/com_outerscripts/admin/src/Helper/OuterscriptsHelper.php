<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Component\Outerscripts\Administrator\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

class OuterscriptsHelper
{

}
