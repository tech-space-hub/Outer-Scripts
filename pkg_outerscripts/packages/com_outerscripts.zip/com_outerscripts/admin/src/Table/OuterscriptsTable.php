<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Component\Outerscripts\Administrator\Table;

defined('JPATH_PLATFORM') or die;

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

class OuterscriptsTable extends Table
{
	public function __construct(DatabaseDriver $db)
	{
		parent::__construct('#__outerscripts', 'id', $db);
	}
}
