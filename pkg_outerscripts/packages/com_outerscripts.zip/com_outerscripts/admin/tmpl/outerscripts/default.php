<?php
/**
 * @package Outerscripts
 * @subpackage com_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Outerscripts\Administrator\Helper\OuterscriptsHelper;

$listOrder = $this->escape($this->state->get('list.ordering'));
$listDirn  = $this->escape($this->state->get('list.direction'));
$editIcon = '<span class="fa fa-pen-square me-2" aria-hidden="true"></span>';
$moreIcon = '<span class="far fa-eye me-2" aria-hidden="true"></span>';
?>
<form action="<?php echo Route::_('index.php?option=com_outerscripts'); ?>" method="post" name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>
				<?php if (empty($this->items)) : ?>
					<div class="alert alert-info">
						<span class="fa fa-info-circle" aria-hidden="true"></span><span class="sr-only"><?php echo Text::_('INFO'); ?></span>
						<?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?>
					</div>
				<?php else : ?>
					<table class="table" id="outerscriptsList">
						<caption id="captionTable">
							<?php echo Text::_('COM_OUTERSCRIPTS_OUTERSCRIPTS_TABLE_CAPTION'); ?>, <?php echo Text::_('JGLOBAL_SORTED_BY'); ?>
						</caption>
						<thead>
							<tr>
								<td style="width:1%" class="text-center">
									<?php echo HTMLHelper::_('grid.checkall'); ?>
								</td>
								<th scope="col" style="width:5%" class="d-none d-md-table-cell">
									<?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?>
								</th>
								<th scope="col" style="width:3%; min-width:85px" class="text-center">
									<?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?>
								</th>
								<th scope="col" style="width:30%">
									<?php echo HTMLHelper::_('searchtools.sort', 'JGLOBAL_TITLE', 'a.title', $listDirn, $listOrder); ?>
								</th>
								<th scope="col" style="width:10%">
									<?php echo Text::_('COM_OUTERSCRIPTS_OUTERSCRIPT_LABEL_TYPE'); ?>
								</th>
								<th scope="col" style="width:51%">
									<?php echo Text::_('COM_OUTERSCRIPTS_OUTERSCRIPTS_LABEL_EXTERNAL_PATH'); ?>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$n = count($this->items);
							foreach ($this->items as $i => $item) :
							?>
								<tr class="row<?php echo $i % 2; ?>">
									<td class="text-center">
										<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
									</td>
									<td class="d-none d-md-table-cell">
										<?php echo $item->id; ?>
									</td>
									<td class="article-status">
										<?php echo HTMLHelper::_('jgrid.published', $item->state, $i, 'outerscripts.'); ?>
									</td>
									<td scope="row" class="has-context">
										<a class="hasTooltip" href="<?php echo Route::_('index.php?option=com_outerscripts&task=outerscript.edit&id=' . $item->id); ?>">
											<?php echo $editIcon; ?><?php echo $this->escape($item->title); ?>
										</a>
									</td>
									<td class="">
										<?php if ($item->type == 1) {
											echo 'PHP';
										} else if ($item->type == 2) {
											echo 'JS';
										} else if ($item->type == 3) {
											echo 'CSS';
										} else if ($item->type == 4) {
											echo 'HTML';
										} ?>
									</td>
									<td class="">
										<?php echo $item->external_path; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
					<?php echo $this->pagination->getListFooter(); ?>
				<?php endif; ?>
				<input type="hidden" name="task" value="">
				<input type="hidden" name="boxchecked" value="0">
				<?php echo HTMLHelper::_('form.token'); ?>
				<input id="token" type="hidden" name="<?php echo JSession::getFormToken(false); ?>" value="1" />
			</div>
		</div>
	</div>
</form>