<?php

/**
 * @package Outerscripts
 * @subpackage mod_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

namespace Joomla\Module\Outerscripts\Site\Helper;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;

defined('_JEXEC') or die;

class OuterscriptsHelper
{
    public static function getOuterscripts($params)
    { 
		$db = Factory::getDbo();
		$query = $db->getQuery(true);
		$outerscript_location = $params->get('outerscript_location', 0);
		
        $query = $db->getQuery(true)
            ->select('id,type,title,inline_code,external_path,state')
            ->from('#__outerscripts')
            ->where('state = 1 ')
			->where('id = '.$outerscript_location)
			->order('id DESC');
        $db->setQuery($query);
		$query = $db->loadObjectList();
		
		return $query;
    }
}
