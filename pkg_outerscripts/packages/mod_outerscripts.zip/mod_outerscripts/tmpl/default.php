<?php

/**
 * @package Outerscripts
 * @subpackage mod_outerscripts
 *
 * @copyright (C) 2023 Tech Space Hub.
 * @license GNU General Public License version 3 or later
*/

defined('_JEXEC') or die;

use Joomla\CMS\Filter\OutputFilter;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

?>

<section class="outerScriptsSectionWrapper">
	<div class="outerscripts-container">
		<?php
		foreach ($outerscripts as $i => $item) :

			$inlineCode = $item->inline_code;
			$externalPath = $item->external_path;

			eval('?>' . $inlineCode);

			if (!empty($externalPath)) {
				$filepath = JPATH_SITE . '/' . $externalPath;
				if (is_file($externalPath)) {
					require_once($externalPath);
				} elseif (is_file($filepath))
					require_once $filepath;
				else{					
					$html = '<div style="color: #ffffff;background: #6b3143;padding: 5px 15px;margin: 10px 0px;">'.Text::_('MOD_OUTERSCRIPTS_OUTERSCRIPT_INVALID_FILE_PATH').'</div>';
					echo sprintf($html, $filepath);
				}
			}

		endforeach;
		?>
	</div>
</section>